package C;

import com.badlogic.gdx.graphics.Color;

public class C {

	// NAME YOUR GAME
	public static CharSequence gameName = "Two Dots";

	// ALWAYS SET TO TRUE
	public static final boolean LEADERBOARDS = true;

	// BANNER ID FROM ADMOB
	public static String AD_UNIT_ID_BANNER = "ca-app-pub-8835239316193144/9724283118";

	// INTERSTITIAL ID FROM ADMOB
	public static String AD_UNIT_ID_INTERSTITIAL = "ca-app-pub-8835239316193144/2201016318";

	// LEADERBOARD ID (you should also set the app_id in res>values>strings.xml)
	public static String LEADERBOARD_ID = "CgkIxYr7wJ0eEAIQAQ";

	// BALL1 COLOR
	public static Color colorB1 = new Color(0.18f, 0.80f, 0.443f, 1f);
	// BALL2 COLOR
	public static Color colorB2 = new Color(0.16f, 0.50f, 0.72f, 1);
	// BACKGROUND COLOR
	public static Color backColor = new Color(0.92f, 0.949f, 0.949f, 1);

	// RADIUS OF THE CENTER CIRCLE
	public static final int radiusCenterCircle = 55;

}
