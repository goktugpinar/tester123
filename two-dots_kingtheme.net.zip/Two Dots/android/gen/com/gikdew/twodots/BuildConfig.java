/** Automatically generated file. DO NOT MODIFY */
package com.gikdew.twodots;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}